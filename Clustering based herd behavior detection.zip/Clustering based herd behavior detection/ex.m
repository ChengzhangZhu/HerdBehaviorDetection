load('clearData.mat')

%% select time periods
% set parameters
beginDate = 45;
period = 5;
% select data
selectData = data(beginDate:beginDate+period,:);
selectLabel = label;
% check empty data
emptyIndex = find(sum(selectData,1)==0);
selectData(:,emptyIndex) = [];
selectLabel(:,emptyIndex) = [];

%% calculate distance between stock return rates
dist = 1 - corr(selectData);
dist = matrix2Dist(dist);

%% obtain clustering result
[centerIndex,halo,classNUM] = cluster_dp(dist);

%% display results
for i = 1 : classNUM
    fprintf('The group %d has the following member:\n', i);
    selectLabel(halo==i)
    fprintf('The group %d center is:\n', i);
    selectLabel(centerIndex(i))
end
% 
%% save group information in every iteration
for i = 1 : classNUM
    groupData = selectLabel(halo==i);
    fid1=['result','.txt'];
    c=fopen(fid1,'a');    
    for j = 1 : length(groupData)
         fprintf(c,'%d ,', groupData(j));        %%%qΪ��Ҫд������ݣ���'%f��Ϊ���ݸ�ʽ
    end
    fprintf(c,'\n');
    fclose(c);
end
